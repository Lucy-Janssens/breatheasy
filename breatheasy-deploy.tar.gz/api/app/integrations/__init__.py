"""
Integrations module for external services
"""

